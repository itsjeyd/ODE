var searchData=
[
  ['global_2ejava',['Global.java',['../Global_8java.html',1,'']]]
];

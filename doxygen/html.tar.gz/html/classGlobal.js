var classGlobal =
[
    [ "onBadRequest", "classGlobal.html#aa08c4516ed664eedfa3986784564a560", null ],
    [ "onError", "classGlobal.html#a5d1546e4eadcb83db8d36f6b1a5081bd", null ],
    [ "onHandlerNotFound", "classGlobal.html#a5cb4baca5e05a95600add8fc8bbaa6cf", null ]
];
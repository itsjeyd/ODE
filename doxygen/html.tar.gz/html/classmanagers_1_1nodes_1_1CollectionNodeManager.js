var classmanagers_1_1nodes_1_1CollectionNodeManager =
[
    [ "delete", "classmanagers_1_1nodes_1_1CollectionNodeManager.html#ac8bde525943e2c1da57e395647f898f0", null ],
    [ "disconnect", "classmanagers_1_1nodes_1_1CollectionNodeManager.html#a500a7482a57cf9def7731aa72b0da164", null ],
    [ "empty", "classmanagers_1_1nodes_1_1CollectionNodeManager.html#a3c371b995de695947f0d62abaabee63e", null ],
    [ "empty", "classmanagers_1_1nodes_1_1CollectionNodeManager.html#a1f949b62a0272facdf1e2af564ba5db6", null ]
];
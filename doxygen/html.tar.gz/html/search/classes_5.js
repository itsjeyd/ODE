var searchData=
[
  ['global',['Global',['../classGlobal.html',1,'']]]
];

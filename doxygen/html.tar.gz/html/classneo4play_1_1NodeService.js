var classneo4play_1_1NodeService =
[
    [ "buildMatchQuery", "classneo4play_1_1NodeService.html#a26d3f7e11c9e56ec832e0cea69da35f0", null ],
    [ "createNode", "classneo4play_1_1NodeService.html#aba60e7771844c8e4ec367cf99f9b1d1d", null ],
    [ "createNode", "classneo4play_1_1NodeService.html#a88437bc01d706cf37f59adb4fea3545b", null ],
    [ "deleteNode", "classneo4play_1_1NodeService.html#a3450e6389be1e5480effe82ac8ba1692", null ],
    [ "getNode", "classneo4play_1_1NodeService.html#a0f9827040951a46d313dae9e08985122", null ],
    [ "getNodes", "classneo4play_1_1NodeService.html#a9e5672625e4292ef2f9b4e1113b301cf", null ],
    [ "updateNode", "classneo4play_1_1NodeService.html#a85fc71416554874095c859d1e61f27e6", null ],
    [ "updateNode", "classneo4play_1_1NodeService.html#a6f93c570766a23798fab357b85774ec5", null ]
];
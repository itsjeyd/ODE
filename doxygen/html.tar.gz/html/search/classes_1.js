var searchData=
[
  ['basemanager',['BaseManager',['../classmanagers_1_1BaseManager.html',1,'managers']]],
  ['booleanfunction',['BooleanFunction',['../classmanagers_1_1functions_1_1BooleanFunction.html',1,'managers::functions']]]
];

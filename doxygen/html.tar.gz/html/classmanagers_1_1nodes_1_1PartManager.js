var classmanagers_1_1nodes_1_1PartManager =
[
    [ "PartManager", "classmanagers_1_1nodes_1_1PartManager.html#abd8330e134e3497e0262643f9ff045b5", null ],
    [ "all", "classmanagers_1_1nodes_1_1PartManager.html#ae9dc88507ed61bfb7bf669097b2d02fb", null ]
];
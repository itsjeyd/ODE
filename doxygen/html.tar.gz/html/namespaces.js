var namespaces =
[
    [ "constants", "namespaceconstants.html", null ],
    [ "controllers", "namespacecontrollers.html", null ],
    [ "managers", "namespacemanagers.html", "namespacemanagers" ],
    [ "models", "namespacemodels.html", "namespacemodels" ],
    [ "neo4play", "namespaceneo4play.html", null ],
    [ "utils", "namespaceutils.html", null ]
];
var searchData=
[
  ['basemanager_2ejava',['BaseManager.java',['../BaseManager_8java.html',1,'']]],
  ['booleanfunction_2ejava',['BooleanFunction.java',['../BooleanFunction_8java.html',1,'']]]
];

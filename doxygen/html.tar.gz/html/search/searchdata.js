var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuv",
  1: "abcefghijlmnoprstuv",
  2: "cmnu",
  3: "abcefghjlmnoprstuv",
  4: "abcdefghijlmoprstuv",
  5: "acdefhjlnoprstuv",
  6: "pr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerator"
};


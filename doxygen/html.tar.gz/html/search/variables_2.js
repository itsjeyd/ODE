var searchData=
[
  ['description',['description',['../classmodels_1_1nodes_1_1Feature.html#a02af8ce438c531c5b7db8c67a853994a',1,'models.nodes.Feature.description()'],['../classmodels_1_1nodes_1_1Rule.html#a7ee40da129ba46c4c8553069a26a4f2a',1,'models.nodes.Rule.description()']]]
];

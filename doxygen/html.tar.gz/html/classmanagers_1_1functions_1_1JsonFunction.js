var classmanagers_1_1functions_1_1JsonFunction =
[
    [ "apply", "classmanagers_1_1functions_1_1JsonFunction.html#a423d0374947551af9871497ec3b28443", null ]
];
var classcontrollers_1_1Application_1_1Login =
[
    [ "validate", "classcontrollers_1_1Application_1_1Login.html#ae18a71d6903931374cad0433f2666174", null ],
    [ "email", "classcontrollers_1_1Application_1_1Login.html#aa20bd914628c4b324f9aeab1d255b610", null ],
    [ "password", "classcontrollers_1_1Application_1_1Login.html#a89dad2aa9d21cbc282615ee39ded10d8", null ]
];
var searchData=
[
  ['typedrelmanager_2ejava',['TypedRelManager.java',['../TypedRelManager_8java.html',1,'']]]
];

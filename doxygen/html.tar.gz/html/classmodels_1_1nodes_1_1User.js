var classmodels_1_1nodes_1_1User =
[
    [ "User", "classmodels_1_1nodes_1_1User.html#aa84881c19154cbe8a0fa6cacc7e3fabd", null ],
    [ "nodes", "classmodels_1_1nodes_1_1User.html#ab3f5322d9646ce9802d404d7d65f2408", null ],
    [ "password", "classmodels_1_1nodes_1_1User.html#af5270771db865edebc524315cb4a7863", null ],
    [ "username", "classmodels_1_1nodes_1_1User.html#af5a1e5e2d77d04bef952ef277d7fa942", null ]
];
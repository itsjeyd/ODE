var classcontrollers_1_1Values =
[
    [ "updateName", "classcontrollers_1_1Values.html#ade46c93cfc7e78fa9ee138574fc67ddb", null ]
];
var classcontrollers_1_1Secured =
[
    [ "getUsername", "classcontrollers_1_1Secured.html#a5f8c2ed95efa1eb6a44e87df1e7c9a32", null ],
    [ "onUnauthorized", "classcontrollers_1_1Secured.html#ad8922081b348dbb071d1efaccf105319", null ]
];
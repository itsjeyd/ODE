var classmanagers_1_1relationships_1_1AllowsManager =
[
    [ "AllowsManager", "classmanagers_1_1relationships_1_1AllowsManager.html#a56145f7d32ad5a10e6229e5eb6280f00", null ]
];
var classmanagers_1_1BaseManager =
[
    [ "beginTransaction", "classmanagers_1_1BaseManager.html#a291342913304c2bceca1addd7a431399", null ],
    [ "commitTransaction", "classmanagers_1_1BaseManager.html#ae6de338d19f2c9a5ec3d4d0cefa0e17d", null ]
];
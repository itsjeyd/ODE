var namespacemanagers =
[
    [ "functions", "namespacemanagers_1_1functions.html", "namespacemanagers_1_1functions" ],
    [ "nodes", "namespacemanagers_1_1nodes.html", "namespacemanagers_1_1nodes" ],
    [ "relationships", "namespacemanagers_1_1relationships.html", "namespacemanagers_1_1relationships" ],
    [ "BaseManager", "classmanagers_1_1BaseManager.html", "classmanagers_1_1BaseManager" ]
];
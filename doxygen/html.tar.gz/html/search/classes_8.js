var searchData=
[
  ['jsonfunction',['JsonFunction',['../classmanagers_1_1functions_1_1JsonFunction.html',1,'managers::functions']]]
];

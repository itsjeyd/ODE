var dir_e9ef5e2aa4ab31cc48867f9e98007845 =
[
    [ "functions", "dir_3c149ad3d39b6ad160c74ddb0c547f94.html", "dir_3c149ad3d39b6ad160c74ddb0c547f94" ],
    [ "nodes", "dir_33b84e144900d1c84debdc163adbd091.html", "dir_33b84e144900d1c84debdc163adbd091" ],
    [ "relationships", "dir_d427dc28bd7e156b6182e73122abd284.html", "dir_d427dc28bd7e156b6182e73122abd284" ],
    [ "BaseManager.java", "BaseManager_8java.html", [
      [ "BaseManager", "classmanagers_1_1BaseManager.html", "classmanagers_1_1BaseManager" ]
    ] ]
];
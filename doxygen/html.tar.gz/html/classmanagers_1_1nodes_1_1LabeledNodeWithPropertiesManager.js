var classmanagers_1_1nodes_1_1LabeledNodeWithPropertiesManager =
[
    [ "connect", "classmanagers_1_1nodes_1_1LabeledNodeWithPropertiesManager.html#a1bd8b0e46d84c6afe24ba8f83b61f2d4", null ],
    [ "disconnect", "classmanagers_1_1nodes_1_1LabeledNodeWithPropertiesManager.html#a1b3e00755bd7b8005fe113326aaf6538", null ]
];